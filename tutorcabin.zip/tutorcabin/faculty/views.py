from django.shortcuts import render;
def index(request):
	return render(request,"tutorcabin/home.html")
def about(request):
	return render(request,"tutorcabin/about.html")